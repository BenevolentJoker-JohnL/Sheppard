import redis.asyncio as redis
import logging
import os
from rich.console import Console

# Create base directories
current_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
logs_dir = os.path.join(current_dir, 'logs')
os.makedirs(logs_dir, exist_ok=True)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(logs_dir, 'app.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

console = Console()

class DatabaseConfig:
    # Data directories
    DATA_DIR = os.path.join(current_dir, 'data')
    CHROMA_DIR = os.path.join(DATA_DIR, 'chroma_persistence')
    CONVERSATIONS_DIR = os.path.join(DATA_DIR, 'conversations')
    MEMORY_DIR = os.path.join(DATA_DIR, 'memory')  # New directory for memory files

    # Create all necessary directories
    for directory in [DATA_DIR, CHROMA_DIR, CONVERSATIONS_DIR, MEMORY_DIR]:
        os.makedirs(directory, exist_ok=True)

    # Database configurations
    EPISODIC_DB = "postgresql://sheppard:1234@localhost/episodic_memory"
    SEMANTIC_DB = "postgresql://sheppard:1234@localhost/semantic_memory"
    CONTEXTUAL_DB = "postgresql://sheppard:1234@localhost/contextual_memory"
    GENERAL_DB = "postgresql://sheppard:1234@localhost/general_memory"
    ABSTRACTED_DB = "postgresql://sheppard:1234@localhost/abstracted_memory"

    # Redis configurations with separate ports for different memory types
    REDIS_CONFIG = {
        "ephemeral": redis.Redis(host='localhost', port=6370, db=0),
        "contextual": redis.Redis(host='localhost', port=6371, db=1),
        "episodic": redis.Redis(host='localhost', port=6372, db=2),
        "semantic": redis.Redis(host='localhost', port=6373, db=3),
        "abstracted": redis.Redis(host='localhost', port=6374, db=4),
    }

    # Memory configuration
    MEMORY_CONFIG = {
        "cache_size": 1000,
        "embedding_batch_size": 10,
        "max_context_length": 4000,
        "context_window_size": 5,
        "importance_threshold": 0.7,
        "similarity_threshold": 0.95,
        "retention_period_days": 30,
        "cleanup_interval_hours": 24
    }

    @staticmethod
    def get_db_url(db_name: str) -> str:
        """Get database URL for specified memory type"""
        return getattr(DatabaseConfig, f"{db_name.upper()}_DB")
