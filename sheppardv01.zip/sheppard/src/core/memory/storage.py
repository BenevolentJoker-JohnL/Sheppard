import json
import logging
import os
from datetime import datetime
from typing import Dict, Any, Optional, List, Tuple
import psycopg2
from psycopg2.pool import SimpleConnectionPool
from psycopg2.extras import RealDictCursor
import chromadb
from chromadb.config import Settings
import asyncio

from ...config.config import DatabaseConfig

logger = logging.getLogger(__name__)

class StorageManager:
    """Manages database storage operations for memory system"""
    
    def __init__(self):
        self.db_pools = {}
        self.redis_clients = DatabaseConfig.REDIS_CONFIG
        self.chroma_client = chromadb.Client(Settings(
            persist_directory=DatabaseConfig.CHROMA_DIR,
            anonymized_telemetry=False
        ))
        self.chroma_collections = {}
        
    async def initialize(self):
        """Initialize storage components"""
        try:
            # Initialize database pools
            for layer in ["episodic", "semantic", "contextual", "general", "abstracted"]:
                self.db_pools[layer] = SimpleConnectionPool(
                    minconn=1,
                    maxconn=10,
                    dsn=DatabaseConfig.get_db_url(layer)
                )
                # Initialize ChromaDB collections
                self.chroma_collections[layer] = self.chroma_client.get_or_create_collection(
                    name=f"{layer}_memories"
                )
            
            # Initialize Redis connections
            for redis_client in self.redis_clients.values():
                await redis_client.ping()
            
            logger.info("Database connection pools initialized successfully")
            return True
        except Exception as e:
            logger.error(f"Error initializing storage components: {str(e)}")
            raise

    async def store_memory(
        self, 
        key: str, 
        value: Dict[str, Any], 
        layer: str, 
        memory_hash: str, 
        importance_score: float, 
        current_state: str
    ) -> bool:
        """Store memory in database with metadata"""
        conn = self.get_connection(layer)
        try:
            with conn.cursor() as cur:
                # Convert embedding to PostgreSQL array format if present
                embedding = value.get('embedding')
                if embedding and isinstance(embedding, list):
                    embedding_array = f"{{{','.join(map(str, embedding))}}}"
                else:
                    embedding_array = None

                # Extract fields from value dict
                metadata = value.get('context_metadata', {})
                entities = value.get('entities', {})
                topics = value.get('topics', {})

                cur.execute(
                    '''INSERT INTO agent_interactions 
                    (timestamp, agent_id, input, response, embedding, entities, 
                     topics, state, memory_hash, importance_score, last_accessed, 
                     access_count, context_metadata) 
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (memory_hash) 
                    DO UPDATE SET access_count = agent_interactions.access_count + 1,
                               last_accessed = CURRENT_TIMESTAMP''',
                    (
                        datetime.now(),
                        value.get('agent_id', 'AI'),
                        value.get('input', ''),
                        value.get('response', ''),
                        embedding_array,
                        json.dumps(entities),
                        json.dumps(topics),
                        current_state,
                        memory_hash,
                        importance_score,
                        datetime.now(),
                        1,
                        json.dumps(metadata)
                    )
                )
            conn.commit()
            logger.info(f"Successfully stored memory with hash {memory_hash} in {layer} layer")
            return True
        except Exception as e:
            logger.error(f"Error storing memory in database: {str(e)}")
            conn.rollback()
            return False
        finally:
            self.return_connection(layer, conn)

    def get_connection(self, layer: str):
        """Get database connection from pool"""
        return self.db_pools[layer].getconn()

    def return_connection(self, layer: str, conn):
        """Return connection to pool"""
        self.db_pools[layer].putconn(conn)

    async def cleanup_connections(self):
        """Cleanup database connections"""
        try:
            # Close database connections
            for pool in self.db_pools.values():
                pool.closeall()
            
            # Close Redis connections
            for redis_client in self.redis_clients.values():
                await redis_client.close()
                
            logger.info("Database connections cleaned up successfully")
        except Exception as e:
            logger.error(f"Error cleaning up database connections: {str(e)}")

    async def retrieve_relevant_memories(
        self,
        user_input: str,
        embedding: List[float],
        embedding_manager
    ) -> Dict[str, Any]:
        """Retrieve relevant memories using embedding similarity"""
        memories = {
            "episodic": [],
            "semantic": [],
            "contextual": []
        }
        
        try:
            for layer in memories.keys():
                collection = self.chroma_collections.get(layer)
                if collection:
                    results = await embedding_manager.query_similar_embeddings(
                        embedding,
                        layer,
                        self.chroma_collections,
                        n_results=5,
                        similarity_threshold=0.6
                    )
                    
                    if results:
                        conn = self.get_connection(layer)
                        try:
                            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                                for result in results:
                                    metadata = result.get('metadata', {})
                                    memory_hash = metadata.get('key', '').split('_')[-1]
                                    
                                    if memory_hash:
                                        cur.execute("""
                                            SELECT * FROM agent_interactions 
                                            WHERE memory_hash = %s
                                            ORDER BY timestamp DESC
                                            LIMIT 1
                                        """, (memory_hash,))
                                        
                                        row = cur.fetchone()
                                        if row:
                                            memories[layer].append({
                                                'content': f"{row['input']}\n{row['response']}",
                                                'metadata': {
                                                    **metadata,
                                                    'timestamp': row['timestamp'],
                                                    'importance_score': row['importance_score']
                                                },
                                                'similarity': result.get('similarity', 0)
                                            })
                        finally:
                            self.return_connection(layer, conn)
                
                # Check Redis cache
                redis_client = self.redis_clients.get(layer)
                if redis_client:
                    try:
                        async for key in redis_client.scan_iter(f"{layer}_*"):
                            cached_data = await redis_client.get(key)
                            if cached_data:
                                if isinstance(cached_data, bytes):
                                    cached_data = cached_data.decode('utf-8')
                                try:
                                    data = json.loads(cached_data)
                                    if datetime.now() - datetime.fromisoformat(data.get('timestamp', '')) <= timedelta(hours=24):
                                        memories[layer].append({
                                            'content': f"{data.get('input', '')}\n{data.get('response', '')}",
                                            'metadata': data,
                                            'source': 'redis'
                                        })
                                except (json.JSONDecodeError, ValueError):
                                    continue
                    except Exception as redis_error:
                        logger.error(f"Error retrieving Redis cache for {layer}: {str(redis_error)}")
            
            return memories
            
        except Exception as e:
            logger.error(f"Error retrieving memories: {str(e)}")
            return memories
