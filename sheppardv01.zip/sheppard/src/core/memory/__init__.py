from .cache import LRUCache
from .stats import MemoryStats
from .storage import StorageManager
from .embeddings import EmbeddingManager
from .cleanup import CleanupManager

__all__ = [
    'LRUCache',
    'MemoryStats',
    'StorageManager',
    'EmbeddingManager',
    'CleanupManager'
]

# Version information
__version__ = '1.0.0'

# Module documentation
__doc__ = """
Memory Management System
=======================

A comprehensive memory management system for AI applications with the following components:

- LRUCache: Least Recently Used cache implementation
- MemoryStats: Statistics tracking for memory operations
- StorageManager: Database storage operations manager
- EmbeddingManager: Embedding generation and processing
- CleanupManager: Memory cleanup operations

Each component is designed to work independently while maintaining compatibility
with the overall system architecture.
"""
