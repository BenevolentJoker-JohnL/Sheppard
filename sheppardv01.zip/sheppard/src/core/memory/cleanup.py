import logging
from datetime import datetime, timedelta
import json
from typing import Set, Dict, Any, Optional
import asyncio

logger = logging.getLogger(__name__)

class CleanupManager:
    def __init__(self, importance_threshold: float):
        self.importance_threshold = importance_threshold
        self.cleanup_running = False
        self.last_cleanup = datetime.now()
        self.cleanup_stats = {
            "total_cleaned": 0,
            "last_cleanup_duration": 0,
            "errors": 0
        }

    async def perform_full_cleanup(self, storage_managers: Dict[str, Any]) -> Dict[str, Any]:
        """Perform full cleanup of all storage types"""
        cleanup_results = {
            "database": [],
            "chroma": [],
            "redis": []
        }
        
        try:
            # Set cutoff date for cleanup
            cutoff_date = datetime.now() - timedelta(days=30)  # Adjust retention period as needed
            
            # Clean database connections
            if 'database' in storage_managers:
                for layer, pool in storage_managers['database'].items():
                    if hasattr(pool, 'getconn'):
                        conn = pool.getconn()
                        try:
                            result = await self.cleanup_database_memories(
                                conn, 
                                layer, 
                                cutoff_date, 
                                set()
                            )
                            cleanup_results["database"].append(result)
                        finally:
                            pool.putconn(conn)

            # Clean ChromaDB collections
            if 'chroma' in storage_managers:
                for collection_name, collection in storage_managers['chroma'].items():
                    result = await self.cleanup_chroma_memories(
                        collection,
                        cutoff_date
                    )
                    cleanup_results["chroma"].append(result)

            # Clean Redis instances
            if 'redis' in storage_managers:
                for db_name, client in storage_managers['redis'].items():
                    result = await self.cleanup_redis_memories(client)
                    cleanup_results["redis"].append(result)

            self.cleanup_stats["last_cleanup_duration"] = (
                datetime.now() - self.last_cleanup
            ).total_seconds()
            self.last_cleanup = datetime.now()
            
            return cleanup_results

        except Exception as e:
            logger.error(f"Error during full cleanup: {str(e)}")
            self.cleanup_stats["errors"] += 1
            return {"error": str(e)}

    async def cleanup_database_memories(
        self,
        conn,
        layer: str,
        cutoff_date: datetime,
        memory_hashes: Set[str]
    ) -> Dict[str, Any]:
        """Clean up old database memories"""
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    DELETE FROM agent_interactions 
                    WHERE timestamp < %s 
                    AND importance_score < %s
                    RETURNING id
                """, (cutoff_date, self.importance_threshold))
                
                deleted = cur.fetchall()
                conn.commit()
                
                return {
                    "deleted_count": len(deleted),
                    "layer": layer,
                    "cutoff_date": cutoff_date.isoformat()
                }
        except Exception as e:
            logger.error(f"Error cleaning up database memories: {str(e)}")
            conn.rollback()
            return {"error": str(e)}

    async def cleanup_chroma_memories(
        self,
        collection,
        cutoff_date: datetime
    ) -> Dict[str, Any]:
        """Clean up old ChromaDB memories"""
        try:
            # Get all documents with metadata
            results = collection.get()
            deleted_count = 0
            
            if results and 'metadatas' in results:
                ids_to_delete = []
                
                for idx, metadata in enumerate(results['metadatas']):
                    if metadata and 'timestamp' in metadata:
                        doc_date = datetime.fromisoformat(metadata['timestamp'])
                        if doc_date < cutoff_date and \
                           float(metadata.get('importance_score', 0)) < self.importance_threshold:
                            ids_to_delete.append(results['ids'][idx])
                
                if ids_to_delete:
                    collection.delete(ids=ids_to_delete)
                    deleted_count = len(ids_to_delete)
            
            return {
                "deleted_count": deleted_count,
                "collection": collection.name,
                "cutoff_date": cutoff_date.isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error cleaning up ChromaDB memories: {str(e)}")
            return {"error": str(e)}

    async def cleanup_redis_memories(
        self,
        redis_client
    ) -> Dict[str, Any]:
        """Clean up Redis cache entries"""
        try:
            # Get all keys
            keys = await redis_client.keys('*')
            deleted_count = 0
            
            for key in keys:
                try:
                    # Get TTL for key
                    ttl = await redis_client.ttl(key)
                    if ttl == -1:  # Key has no TTL
                        value = await redis_client.get(key)
                        if value:
                            try:
                                data = json.loads(value)
                                if isinstance(data, dict) and 'importance_score' in data:
                                    if float(data['importance_score']) < self.importance_threshold:
                                        await redis_client.delete(key)
                                        deleted_count += 1
                            except json.JSONDecodeError:
                                continue
                except Exception as key_error:
                    logger.error(f"Error processing Redis key {key}: {str(key_error)}")
                    continue
            
            return {
                "deleted_count": deleted_count,
                "database": redis_client.connection_pool.connection_kwargs.get('db', 0)
            }
            
        except Exception as e:
            logger.error(f"Error cleaning up Redis memories: {str(e)}")
            return {"error": str(e)}
