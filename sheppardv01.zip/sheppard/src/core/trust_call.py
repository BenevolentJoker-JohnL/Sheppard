import json
import logging
from typing import Any, Dict, Union, Callable
from jsonschema import validate as validate_schema
from jsonpatch import JsonPatch
from pydantic import BaseModel

logger = logging.getLogger(__name__)

class TrustCall:
    def __init__(self, llm_client):
        self.llm_client = llm_client
        self.existing_schemas = {}
        self.tools = {}

    def register_schema(self, name: str, schema: Union[Dict[str, Any], BaseModel, Callable]):
        """Register a schema with default values"""
        try:
            if isinstance(schema, dict):
                final_schema = schema.copy()
                # Add default empty values for validation
                default_instance = {
                    'name': 'default_name'  # Add a default name since it's required
                }
                validate_schema(instance=default_instance, schema=final_schema)
                self.existing_schemas[name] = final_schema
            elif isinstance(schema, BaseModel):
                self.existing_schemas[name] = schema.schema()
            elif callable(schema):
                self.existing_schemas[name] = self._function_to_schema(schema)
            else:
                raise ValueError("Schema must be a dict, Pydantic BaseModel, or callable")
                
            logger.info(f"Successfully registered schema: {name}")
            
        except Exception as e:
            logger.error(f"Error registering schema {name}: {str(e)}")
            raise

    def _function_to_schema(self, func: Callable) -> Dict[str, Any]:
        schema = {
            "type": "object",
            "properties": {},
            "required": []
        }
        for param_name, param in func.__annotations__.items():
            if param_name != 'return':
                schema["properties"][param_name] = {"type": self._type_to_json_type(param)}
                schema["required"].append(param_name)
        return schema

    def _type_to_json_type(self, py_type):
        type_map = {
            str: "string",
            int: "integer",
            float: "number",
            bool: "boolean",
            list: "array",
            dict: "object"
        }
        return type_map.get(py_type, "string")

    def register_tool(self, name: str, func: Callable):
        """Register a tool with its schema"""
        try:
            self.tools[name] = func
            self.register_schema(name, func)
            logger.info(f"Successfully registered tool: {name}")
        except Exception as e:
            logger.error(f"Error registering tool {name}: {str(e)}")
            raise

    async def execute_tool(self, name: str, **kwargs):
        """Execute a registered tool"""
        if name not in self.tools:
            raise ValueError(f"Tool '{name}' not found")
        
        try:
            schema = self.existing_schemas[name]
            validate_schema(instance=kwargs, schema=schema)
            return await self.tools[name](**kwargs)
        except Exception as e:
            logger.error(f"Error executing tool {name}: {str(e)}")
            raise
