import logging
from typing import Dict, Any, List
import json

logger = logging.getLogger(__name__)

class ResponseGenerator:
    """Handles response generation and processing"""
    
    def __init__(
        self,
        main_client,
        short_context_client,
        long_context_client,
        main_model,
        short_model,
        long_model
    ):
        self.main_client = main_client
        self.short_context_client = short_context_client
        self.long_context_client = long_context_client
        self.main_model = main_model
        self.short_model = short_model
        self.long_model = long_model
        self.max_context_length = 4000
        
        self.system_prompt = (
            "You are Sheppard, an AI assistant powered by Ollama models, specializing in "
            "general problem-solving. Your responses should be informative, helpful, and context-aware. "
            "Use the available tools when necessary to assist the user effectively."
        )

    async def generate(
        self,
        user_input: str,
        memories: Dict[str, Any],
        conversation_history: List[Dict[str, str]],
        tool_analysis: Dict[str, Any]
    ) -> str:
        """Generate response based on input and context"""
        try:
            # Build context summary
            context_summary = await self._summarize_context(memories)
            
            # Build messages
            messages = self._build_messages(
                user_input,
                context_summary,
                conversation_history,
                tool_analysis
            )
            
            # Get response from appropriate model
            response = await self._get_model_response(messages)
            
            if isinstance(response, dict) and 'message' in response:
                return response['message']['content']
            
            raise ValueError("Unexpected response format")
            
        except Exception as e:
            logger.error(f"Error generating response: {str(e)}")
            return "I encountered an error while generating a response. Could you please try again?"

    async def _summarize_context(self, memories: Dict[str, Any]) -> str:
        """Summarize memory context"""
        try:
            memory_texts = []
            for layer, layer_memories in memories.items():
                for memory in layer_memories:
                    if isinstance(memory, dict):
                        content = memory.get('content', '')
                        if content:
                            memory_texts.append(f"{layer}: {content}")

            if not memory_texts:
                return ""

            response = await self.short_context_client.chat(
                model=self.short_model,
                messages=[
                    {
                        "role": "system",
                        "content": "Summarize the following context concisely:"
                    },
                    {
                        "role": "user",
                        "content": "\n".join(memory_texts)
                    }
                ]
            )
            
            if isinstance(response, dict) and 'message' in response:
                return response['message']['content']
            return ""
            
        except Exception as e:
            logger.error(f"Error summarizing context: {str(e)}")
            return ""

    def _build_messages(
        self,
        user_input: str,
        context_summary: str,
        conversation_history: List[Dict[str, str]],
        tool_analysis: Dict[str, Any]
    ) -> List[Dict[str, str]]:
        """Build messages for model interaction"""
        messages = [
            {"role": "system", "content": self.system_prompt},
            {"role": "system", "content": f"Context: {context_summary}"}
        ]
        
        if tool_analysis:
            messages.append({
                "role": "system",
                "content": f"Tool Analysis: {json.dumps(tool_analysis)}"
            })
        
        # Add recent conversation history
        messages.extend(conversation_history[-5:])  # Last 5 exchanges
        messages.append({"role": "user", "content": user_input})
        
        return messages

    async def _get_model_response(
        self,
        messages: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        """Get response from appropriate model based on context length"""
        try:
            total_length = sum(len(m['content']) for m in messages)
            
            if total_length > self.max_context_length:
                return await self.long_context_client.chat(
                    model=self.long_model,
                    messages=messages
                )
            
            return await self.main_client.chat(
                model=self.main_model,
                messages=messages
            )
            
        except Exception as e:
            logger.error(f"Error getting model response: {str(e)}")
            raise
