import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
import json

from ..memory import (
    LRUCache, 
    MemoryStats, 
    StorageManager, 
    EmbeddingManager, 
    CleanupManager
)
from ...config.config import DatabaseConfig

logger = logging.getLogger(__name__)

class MemoryOperations:
    """Handles memory operations and integration"""
    
    def __init__(self, embedding_client, embedding_model, memory_config):
        self.memory_stats = MemoryStats()
        self.memory_cache = LRUCache(memory_config["cache_size"])
        self.storage_manager = StorageManager()
        self.embedding_manager = EmbeddingManager(
            embedding_client,
            embedding_model
        )
        self.cleanup_manager = CleanupManager(
            importance_threshold=memory_config["importance_threshold"]
        )

    async def initialize(self) -> bool:
        """Initialize memory components"""
        return await self.storage_manager.initialize()

    async def generate_embedding(self, text: str) -> Optional[List[float]]:
        """Generate embedding for text"""
        try:
            embedding = await self.embedding_manager.generate_embedding(text)
            if embedding:
                self.memory_stats.record_embedding_operation(True)
            else:
                self.memory_stats.record_embedding_operation(False)
            return embedding
        except Exception as e:
            logger.error(f"Error generating embedding: {str(e)}")
            self.memory_stats.record_embedding_operation(False)
            return None

    async def retrieve_memories(
        self,
        user_input: str,
        embedding: List[float]
    ) -> Dict[str, Any]:
        """Retrieve relevant memories"""
        try:
            # Check cache first
            cache_key = hash(user_input)
            cached_result = await self.memory_cache.get_cached_response(str(cache_key))
            if cached_result:
                return json.loads(cached_result)

            # Get memories from storage
            memories = await self.storage_manager.retrieve_relevant_memories(
                user_input,
                embedding,
                self.embedding_manager
            )

            # Cache the result
            await self.memory_cache.cache_response(
                str(cache_key),
                json.dumps(memories)
            )

            return memories
        except Exception as e:
            logger.error(f"Error retrieving memories: {str(e)}")
            return {"episodic": [], "semantic": [], "contextual": []}

    async def store_interaction(
        self,
        user_input: str,
        response: str,
        embedding: List[float],
        memories: Dict[str, Any]
    ) -> None:
        """Store interaction in memory system"""
        try:
            timestamp = datetime.now().isoformat()
            importance_score = self._calculate_importance(user_input, response)
            
            interaction_data = {
                "timestamp": timestamp,
                "agent_id": "AI",
                "input": user_input,
                "response": response,
                "embedding": embedding,
                "entities": {},  # To be filled by entity extraction
                "topics": {},    # To be filled by topic extraction
                "state": "active",
                "importance_score": importance_score,
                "context_metadata": {
                    "memories_used": memories
                }
            }

            memory_hash = self._generate_hash(interaction_data)

            # Store in each memory layer
            for layer in ["episodic", "semantic", "contextual"]:
                success = await self.storage_manager.store_memory(
                    key=f"interaction_{timestamp}",
                    value=interaction_data,
                    layer=layer,
                    memory_hash=memory_hash,
                    importance_score=importance_score,
                    current_state="active"
                )
                
                if success:
                    self.memory_stats.record_memory_creation("active")
                else:
                    logger.error(f"Failed to store memory in {layer} layer")

        except Exception as e:
            logger.error(f"Error storing interaction: {str(e)}")

    def _calculate_importance(self, user_input: str, response: str) -> float:
        """Calculate importance score for memory"""
        try:
            importance = 0.5  # Base importance
            
            # Define importance indicators
            indicators = {
                "remember": 0.15,
                "important": 0.15,
                "crucial": 0.15,
                "key": 0.1,
                "critical": 0.15,
                "essential": 0.1,
                "priority": 0.1,
                "favorite": 0.15
            }
            
            # Check for indicators in input
            input_lower = user_input.lower()
            for word, score in indicators.items():
                if word in input_lower:
                    importance += score
            
            # Adjust based on content length
            content_length = len(user_input) + len(response)
            importance += min(content_length / 1000, 0.2)
            
            return min(max(importance, 0.0), 1.0)
            
        except Exception as e:
            logger.error(f"Error calculating importance score: {str(e)}")
            return 0.5

    def _generate_hash(self, data: Dict[str, Any]) -> str:
        """Generate unique hash for memory"""
        try:
            # Create a copy without the embedding field
            hash_data = {k: v for k, v in data.items() if k != "embedding"}
            return str(hash(json.dumps(hash_data, sort_keys=True)))
        except Exception as e:
            logger.error(f"Error generating memory hash: {str(e)}")
            return str(datetime.now().timestamp())

    def get_stats_summary(self) -> Dict[str, Any]:
        """Get memory statistics summary"""
        return self.memory_stats.get_stats_summary()

    async def shutdown(self) -> None:
        """Clean shutdown of memory components"""
        try:
            await self.cleanup_manager.perform_full_cleanup({
                'database': self.storage_manager.db_pools,
                'chroma': self.storage_manager.chroma_collections,
                'redis': self.storage_manager.redis_clients
            })
            await self.embedding_manager.shutdown()
            await self.storage_manager.cleanup_connections()
            self.memory_cache.clear()
        except Exception as e:
            logger.error(f"Error during memory operations shutdown: {str(e)}")
