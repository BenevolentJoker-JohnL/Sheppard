from .core import Sheppard
from .memory_ops import MemoryOperations
from .response import ResponseGenerator
from .tools import ToolManager
from .interaction import InteractionHandler

__all__ = [
    'Sheppard',
    'MemoryOperations',
    'ResponseGenerator',
    'ToolManager',
    'InteractionHandler'
]

# Version information
__version__ = '1.0.0'

# Module documentation
__doc__ = """
Sheppard AI Assistant
====================

A conversational AI assistant with advanced memory management and tool capabilities.
The system uses multiple specialized models for different aspects of processing:

- Main Chat: llama3.1:latest for primary conversation
- Short Context: llama3.2:latest for quick context processing
- Long Context: mistral-nemo for handling extended conversations
- Embeddings: nomic-embed-text for semantic analysis
"""
