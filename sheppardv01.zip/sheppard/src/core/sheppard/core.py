import logging
from datetime import datetime
from typing import Dict, Any
from ollama import AsyncClient

from .memory_ops import MemoryOperations
from .interaction import InteractionHandler
from .response import ResponseGenerator
from .tools import ToolManager
from ...config.config import DatabaseConfig, console

logger = logging.getLogger(__name__)

class Sheppard:
    """Main Sheppard AI Assistant class"""
    
    def __init__(self):
        self._init_clients()
        self._init_components()
        self.conversation_history = []
        self.max_history = 10

    def _init_clients(self):
        """Initialize Ollama clients and models"""
        self.main_chat_client = AsyncClient(host='http://localhost:11434')
        self.short_context_client = AsyncClient(host='http://localhost:11434')
        self.long_context_client = AsyncClient(host='http://localhost:11434')
        self.embedding_client = AsyncClient(host='http://localhost:11434')
        
        # Model specifications - maintained as required
        self.main_chat_model = "llama3.1:latest"
        self.short_context_model = "llama3.2:latest"
        self.long_context_model = "mistral-nemo"
        self.embedding_model = "nomic-embed-text"

    def _init_components(self):
        """Initialize system components"""
        # Memory operations handler
        self.memory_ops = MemoryOperations(
            self.embedding_client,
            self.embedding_model,
            DatabaseConfig.MEMORY_CONFIG
        )
        
        # Response generation
        self.response_gen = ResponseGenerator(
            self.main_chat_client,
            self.short_context_client,
            self.long_context_client,
            self.main_chat_model,
            self.short_context_model,
            self.long_context_model
        )
        
        # Tool management
        self.tool_manager = ToolManager(self.main_chat_client)
        
        # Interaction handling
        self.interaction = InteractionHandler(
            self.memory_ops,
            self.response_gen,
            self.tool_manager
        )

    async def initialize(self):
        """Initialize all system components"""
        try:
            await self.memory_ops.initialize()
            await self.tool_manager.initialize()
            logger.info("Sheppard initialized successfully")
            return True
        except Exception as e:
            logger.error(f"Error during initialization: {str(e)}")
            raise

    async def process_input(self, user_input: str) -> str:
        """Process user input and generate response"""
        try:
            response = await self.interaction.process(
                user_input,
                self.conversation_history
            )
            self._update_conversation_history(user_input, response)
            return response
        except Exception as e:
            logger.error(f"Error processing input: {str(e)}")
            return "I encountered an unexpected issue. Please try again."

    def _update_conversation_history(self, user_input: str, response: str) -> None:
        """Update conversation history with bounds checking"""
        try:
            self.conversation_history.append({"role": "user", "content": user_input})
            self.conversation_history.append({"role": "assistant", "content": response})
            
            if len(self.conversation_history) > self.max_history * 2:
                self.conversation_history = (
                    self.conversation_history[:2] +
                    self.conversation_history[-self.max_history*2+2:]
                )
        except Exception as e:
            logger.error(f"Error updating conversation history: {str(e)}")

    async def shutdown(self):
        """Clean shutdown of all components"""
        try:
            await self.memory_ops.shutdown()
            await self.tool_manager.shutdown()
            logger.info("Sheppard shutdown completed successfully")
        except Exception as e:
            logger.error(f"Error during shutdown: {str(e)}")
