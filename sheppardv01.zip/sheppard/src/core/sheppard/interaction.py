import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

class InteractionHandler:
    """Handles processing of user interactions"""
    
    def __init__(self, memory_ops, response_gen, tool_manager):
        self.memory_ops = memory_ops
        self.response_gen = response_gen
        self.tool_manager = tool_manager

    async def process(
        self,
        user_input: str,
        conversation_history: List[Dict[str, str]]
    ) -> str:
        """Process user input and generate response"""
        try:
            # Generate embedding for input
            user_embedding = await self.memory_ops.generate_embedding(user_input)
            if not user_embedding:
                return "I'm having trouble processing your input right now. Please try again."

            # Retrieve relevant memories
            memories = await self.memory_ops.retrieve_memories(
                user_input,
                user_embedding
            )

            # Analyze for tool usage
            tool_analysis = await self.tool_manager.analyze_input(
                user_input,
                memories
            )

            # Generate response
            response = await self.response_gen.generate(
                user_input,
                memories,
                conversation_history,
                tool_analysis
            )

            # Handle any tool calls
            if tool_analysis.get('use_tools'):
                response = await self.tool_manager.process_response(
                    response,
                    tool_analysis
                )

            # Store interaction
            await self.memory_ops.store_interaction(
                user_input,
                response,
                user_embedding,
                memories
            )

            return response

        except Exception as e:
            logger.error(f"Error processing interaction: {str(e)}")
            return "I encountered an unexpected issue. Please try again."
