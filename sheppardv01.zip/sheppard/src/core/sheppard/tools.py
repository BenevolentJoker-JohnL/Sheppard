import logging
from typing import Dict, Any, List
import json
import asyncio

from ..trust_call import TrustCall

logger = logging.getLogger(__name__)

class ToolManager:
    """Manages tool registration and execution"""
    
    def __init__(self, client):
        self.client = client
        self.trust_call = TrustCall(client)
        self._register_default_tools()

    def _register_default_tools(self):
        """Register default tools"""
        self.trust_call.register_tool("calculate", self.calculate)
        self.trust_call.register_tool("search_web", self.search_web)
        self.trust_call.register_tool("summarize_text", self.summarize_text)

    async def initialize(self):
        """Initialize tool manager"""
        try:
            # Register default schemas
            self.trust_call.register_schema("user_profile", {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "preferences": {"type": "object"}
                }
            })
            return True
        except Exception as e:
            logger.error(f"Error initializing tool manager: {str(e)}")
            return False

    async def analyze_input(
        self,
        user_input: str,
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Analyze if tools should be used"""
        try:
            response = await self.client.chat(
                model="llama3.2:latest",  # Using short context model
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "Analyze if tools should be used. "
                            "Available tools: calculate, search_web, summarize_text. "
                            "Return a JSON object with tool recommendations."
                        )
                    },
                    {
                        "role": "user",
                        "content": f"Input: {user_input}\nContext: {json.dumps(context)}"
                    }
                ]
            )
            
            if isinstance(response, dict) and 'message' in response:
                try:
                    return json.loads(response['message']['content'])
                except json.JSONDecodeError:
                    return {}
            return {}
            
        except Exception as e:
            logger.error(f"Error analyzing for tools: {str(e)}")
            return {}

    async def process_response(
        self,
        response: str,
        tool_analysis: Dict[str, Any]
    ) -> str:
        """Process response and handle tool calls"""
        try:
            tool_calls = self._extract_tool_calls(response, tool_analysis)
            
            for tool_call in tool_calls:
                tool_result = await self.trust_call.execute_tool(**tool_call)
                response += f"\n\nTool '{tool_call['name']}' result: {tool_result}"
                
            return response
            
        except Exception as e:
            logger.error(f"Error processing tool response: {str(e)}")
            return response

    def _extract_tool_calls(
        self,
        response: str,
        tool_analysis: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """Extract tool calls from response"""
        tool_calls = []
        recommended_tools = tool_analysis.get('recommended_tools', [])
        
        try:
            if "Use tool:" in response or recommended_tools:
                lines = response.split("\n")
                for line in lines:
                    if line.startswith("Use tool:"):
                        parts = line.split(":", 1)
                        if len(parts) == 2:
                            tool_info = parts[1].strip().split(" ", 1)
                            if len(tool_info) == 2:
                                tool_name, args_str = tool_info
                                try:
                                    args = json.loads(args_str)
                                    if tool_name in recommended_tools:
                                        tool_calls.append({
                                            "name": tool_name,
                                            **args
                                        })
                                except json.JSONDecodeError:
                                    logger.error(f"Failed to parse tool arguments: {args_str}")
            return tool_calls
            
        except Exception as e:
            logger.error(f"Error extracting tool calls: {str(e)}")
            return []

    # Default tool implementations
    async def calculate(self, expression: str) -> str:
        """Calculate mathematical expression safely"""
        try:
            safe_dict = {
                "abs": abs, "float": float, "int": int,
                "max": max, "min": min, "pow": pow,
                "round": round, "sum": sum
            }
            
            result = eval(expression, {"__builtins__": {}}, safe_dict)
            return str(result)
            
        except Exception as e:
            return f"Error in calculation: {str(e)}"

    async def search_web(self, query: str) -> str:
        """Simulate web search (placeholder)"""
        return f"Web search results for: {query}"

    async def summarize_text(self, text: str) -> str:
        """Summarize text using short context model"""
        try:
            response = await self.client.chat(
                model="llama3.2:latest",
                messages=[
                    {
                        "role": "system",
                        "content": "Summarize the following text concisely:"
                    },
                    {
                        "role": "user",
                        "content": text
                    }
                ]
            )
            
            if isinstance(response, dict) and 'message' in response:
                return response['message']['content']
            return "Unable to generate summary."
            
        except Exception as e:
            logger.error(f"Error in summarize_text: {str(e)}")
            return f"Error generating summary: {str(e)}"

    async def shutdown(self) -> None:
        """Cleanup tool manager resources"""
        try:
            # Add any cleanup tasks here
            pass
        except Exception as e:
            logger.error(f"Error during tool manager shutdown: {str(e)}")
